var backgroundDictionary = {
	"images": [
		{ "filename" : "0", "source_url": "https://res.cloudinary.com/dp3zinfdz/image/upload/v1444580562/Web_Document_s9j4wl.jpg" }

		// { "filename" : "0", "source_url": "https://res.cloudinary.com/calhack/image/upload/v1444539518/1.jpg" },
		// {"filename" : "1", "source_url": "http://res.cloudinary.com/calhack/image/upload/v1444539518/2.jpg"},
		// {"filename" : "2", "source_url": "http://res.cloudinary.com/calhack/image/upload/v1444539525/3.jpg"}, 
		// {"filename" : "3", "source_url": "http://res.cloudinary.com/calhack/image/upload/v1444543710/4_e8mk5f.jpg"} 
	]
}
